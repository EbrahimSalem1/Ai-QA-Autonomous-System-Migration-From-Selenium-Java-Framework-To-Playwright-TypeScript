// Generated from: features/product-compare.feature
import { test } from "../../src/fixtures/fixtures.ts";

test.describe('Product compare', () => {

  test('Add a product to the comparison', { tag: ['@compare', '@IB-19', '@smoke'] }, async ({ Given, When, Then, currentPage, productPage, shopper }) => { 
    await Given('I am on the product page of "iPhone"', null, { shopper }); 
    await When('I add the product to the comparison', null, { productPage }); 
    await Then('I see the success message "Success: You have added iPhone to your product comparison!"', null, { currentPage }); 
  });

  test('Compare two products side by side', { tag: ['@compare', '@IB-19'] }, async ({ Given, When, Then, comparePage, shopper }) => { 
    await Given('I have added the following products to the comparison:', {"dataTable":{"rows":[{"cells":[{"value":"iPhone"}]},{"cells":[{"value":"MacBook"}]}]}}, { shopper }); 
    await When('I open the product comparison page', null, { comparePage }); 
    await Then('the product comparison contains:', {"dataTable":{"rows":[{"cells":[{"value":"iPhone"}]},{"cells":[{"value":"MacBook"}]}]}}, { comparePage }); 
  });

  test('Remove a product from the comparison', { tag: ['@compare', '@IB-19'] }, async ({ Given, When, Then, And, comparePage, currentPage, shopper }) => { 
    await Given('I have added the following products to the comparison:', {"dataTable":{"rows":[{"cells":[{"value":"iPhone"}]},{"cells":[{"value":"MacBook"}]}]}}, { shopper }); 
    await And('I open the product comparison page', null, { comparePage }); 
    await When('I remove "iPhone" from the comparison', null, { comparePage }); 
    await Then('I see the success message "Success: You have modified your product comparison!"', null, { currentPage }); 
    await And('the product comparison contains:', {"dataTable":{"rows":[{"cells":[{"value":"MacBook"}]}]}}, { comparePage }); 
    await And('the product comparison does not contain "iPhone"', null, { comparePage }); 
  });

  test('An empty comparison shows an empty message', { tag: ['@compare', '@IB-19'] }, async ({ When, Then, comparePage, currentPage }) => { 
    await When('I open the product comparison page', null, { comparePage }); 
    await Then('I see the message "You have not chosen any products to compare."', null, { currentPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/product-compare.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":8,"tags":["@compare","@IB-19","@smoke"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I am on the product page of \"iPhone\"","stepMatchArguments":[{"group":{"start":28,"value":"\"iPhone\"","children":[{"start":29,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":8,"gherkinStepLine":10,"keywordType":"Action","textWithKeyword":"When I add the product to the comparison","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":11,"keywordType":"Outcome","textWithKeyword":"Then I see the success message \"Success: You have added iPhone to your product comparison!\"","stepMatchArguments":[{"group":{"start":26,"value":"\"Success: You have added iPhone to your product comparison!\"","children":[{"start":27,"value":"Success: You have added iPhone to your product comparison!","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":12,"pickleLine":13,"tags":["@compare","@IB-19"],"steps":[{"pwStepLine":13,"gherkinStepLine":14,"keywordType":"Context","textWithKeyword":"Given I have added the following products to the comparison:","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"When I open the product comparison page","stepMatchArguments":[]},{"pwStepLine":15,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"Then the product comparison contains:","stepMatchArguments":[]}]},
  {"pwTestLine":18,"pickleLine":22,"tags":["@compare","@IB-19"],"steps":[{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Context","textWithKeyword":"Given I have added the following products to the comparison:","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":26,"keywordType":"Context","textWithKeyword":"And I open the product comparison page","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"When I remove \"iPhone\" from the comparison","stepMatchArguments":[{"group":{"start":9,"value":"\"iPhone\"","children":[{"start":10,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then I see the success message \"Success: You have modified your product comparison!\"","stepMatchArguments":[{"group":{"start":26,"value":"\"Success: You have modified your product comparison!\"","children":[{"start":27,"value":"Success: You have modified your product comparison!","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":23,"gherkinStepLine":29,"keywordType":"Outcome","textWithKeyword":"And the product comparison contains:","stepMatchArguments":[]},{"pwStepLine":24,"gherkinStepLine":31,"keywordType":"Outcome","textWithKeyword":"And the product comparison does not contain \"iPhone\"","stepMatchArguments":[{"group":{"start":40,"value":"\"iPhone\"","children":[{"start":41,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":27,"pickleLine":33,"tags":["@compare","@IB-19"],"steps":[{"pwStepLine":28,"gherkinStepLine":34,"keywordType":"Action","textWithKeyword":"When I open the product comparison page","stepMatchArguments":[]},{"pwStepLine":29,"gherkinStepLine":35,"keywordType":"Outcome","textWithKeyword":"Then I see the message \"You have not chosen any products to compare.\"","stepMatchArguments":[{"group":{"start":18,"value":"\"You have not chosen any products to compare.\"","children":[{"start":19,"value":"You have not chosen any products to compare.","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end