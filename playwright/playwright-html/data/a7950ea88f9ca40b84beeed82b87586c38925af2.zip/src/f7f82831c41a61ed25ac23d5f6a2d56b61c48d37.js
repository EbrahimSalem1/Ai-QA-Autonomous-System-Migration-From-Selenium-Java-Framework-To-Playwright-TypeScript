// Generated from: features/product-details.feature
import { test } from "../../src/fixtures/fixtures.ts";

test.describe('Product details page', () => {

  test('Product information is shown', { tag: ['@product', '@IB-16', '@smoke'] }, async ({ Given, When, Then, And, header, homePage, productPage, searchResultsPage }) => { 
    await Given('I am on the home page', null, { homePage }); 
    await When('I search for "MacBook"', null, { header }); 
    await And('I open the product "MacBook"', null, { productPage, searchResultsPage }); 
    await Then('the product heading is "MacBook"', null, { productPage }); 
    await And('the product price is displayed', null, { productPage }); 
    await And('the quantity field and the Add to Cart button are displayed', null, { productPage }); 
    await And('the product tabs "Description" and "Reviews" are available', null, { productPage }); 
  });

  test('Add a product to the cart with a chosen quantity', { tag: ['@product', '@IB-16'] }, async ({ Given, When, Then, currentPage, productPage, shopper }) => { 
    await Given('I am on the product page of "iPhone"', null, { shopper }); 
    await When('I set the quantity to 2 and add the product to the cart', null, { productPage }); 
    await Then('I see the success message "Success: You have added iPhone to your shopping cart!"', null, { currentPage }); 
  });

  test('Wish list and compare actions are available', { tag: ['@product', '@IB-16'] }, async ({ Given, Then, productPage, shopper }) => { 
    await Given('I am on the product page of "iPhone"', null, { shopper }); 
    await Then('the "Add to Wish List" and "Compare this Product" buttons are displayed', null, { productPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/product-details.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":8,"tags":["@product","@IB-16","@smoke"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I am on the home page","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":10,"keywordType":"Action","textWithKeyword":"When I search for \"MacBook\"","stepMatchArguments":[{"group":{"start":13,"value":"\"MacBook\"","children":[{"start":14,"value":"MacBook","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"And I open the product \"MacBook\"","stepMatchArguments":[{"group":{"start":19,"value":"\"MacBook\"","children":[{"start":20,"value":"MacBook","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":10,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"Then the product heading is \"MacBook\"","stepMatchArguments":[{"group":{"start":23,"value":"\"MacBook\"","children":[{"start":24,"value":"MacBook","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":11,"gherkinStepLine":13,"keywordType":"Outcome","textWithKeyword":"And the product price is displayed","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":14,"keywordType":"Outcome","textWithKeyword":"And the quantity field and the Add to Cart button are displayed","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":15,"keywordType":"Outcome","textWithKeyword":"And the product tabs \"Description\" and \"Reviews\" are available","stepMatchArguments":[{"group":{"start":17,"value":"\"Description\"","children":[{"start":18,"value":"Description","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":35,"value":"\"Reviews\"","children":[{"start":36,"value":"Reviews","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":16,"pickleLine":17,"tags":["@product","@IB-16"],"steps":[{"pwStepLine":17,"gherkinStepLine":18,"keywordType":"Context","textWithKeyword":"Given I am on the product page of \"iPhone\"","stepMatchArguments":[{"group":{"start":28,"value":"\"iPhone\"","children":[{"start":29,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"When I set the quantity to 2 and add the product to the cart","stepMatchArguments":[{"group":{"start":22,"value":"2"},"parameterTypeName":"int"}]},{"pwStepLine":19,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then I see the success message \"Success: You have added iPhone to your shopping cart!\"","stepMatchArguments":[{"group":{"start":26,"value":"\"Success: You have added iPhone to your shopping cart!\"","children":[{"start":27,"value":"Success: You have added iPhone to your shopping cart!","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":22,"pickleLine":22,"tags":["@product","@IB-16"],"steps":[{"pwStepLine":23,"gherkinStepLine":23,"keywordType":"Context","textWithKeyword":"Given I am on the product page of \"iPhone\"","stepMatchArguments":[{"group":{"start":28,"value":"\"iPhone\"","children":[{"start":29,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":24,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"Then the \"Add to Wish List\" and \"Compare this Product\" buttons are displayed","stepMatchArguments":[{"group":{"start":4,"value":"\"Add to Wish List\"","children":[{"start":5,"value":"Add to Wish List","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":27,"value":"\"Compare this Product\"","children":[{"start":28,"value":"Compare this Product","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end