// Generated from: features/checkout.feature
import { test } from "../../src/fixtures/fixtures.ts";

test.describe('Checkout', () => {

  test('Guest checkout places an order', { tag: ['@checkout', '@IB-20', '@smoke', '@e2e'] }, async ({ Given, When, Then, And, cartPage, checkoutPage, currentPage, shopper }) => { 
    await Given('I have added "iPhone" to the shopping cart', null, { shopper }); 
    await When('I proceed to checkout', null, { cartPage }); 
    await And('I check out as a guest with valid personal details and address', null, { checkoutPage }); 
    await And('I choose the shipping method "Flat Shipping Rate"', null, { checkoutPage }); 
    await And('I agree to the terms and conditions', null, { checkoutPage }); 
    await And('I choose the payment method "Cash On Delivery"', null, { checkoutPage }); 
    await And('I confirm the order', null, { checkoutPage }); 
    await Then('the page heading is "Your order has been placed!"', null, { currentPage }); 
  });

  test('A logged-in customer reaches checkout without the account step', { tag: ['@checkout', '@IB-20', '@auth'] }, async ({ Given, When, Then, And, accountPage, cartPage, checkoutPage, currentPage, shopper }) => { 
    await Given('I am logged in', null, { accountPage }); 
    await And('I have added "MacBook" to the shopping cart', null, { shopper }); 
    await When('I proceed to checkout', null, { cartPage }); 
    await Then('the page heading is "Checkout"', null, { currentPage }); 
    await And('the guest checkout option is not offered', null, { checkoutPage }); 
  });

  test('Checkout with an empty cart returns to the shopping cart', { tag: ['@checkout', '@IB-20'] }, async ({ When, Then, And, checkoutPage, currentPage }) => { 
    await When('I open the checkout page', null, { checkoutPage }); 
    await Then('the page heading is "Shopping Cart"', null, { currentPage }); 
    await And('I see the message "Your shopping cart is empty!"', null, { currentPage }); 
  });

  test('The order cannot be confirmed until the terms and conditions are accepted', { tag: ['@checkout', '@IB-20'] }, async ({ Given, When, Then, And, cartPage, checkoutPage, shopper }) => { 
    await Given('I have added "iPhone" to the shopping cart', null, { shopper }); 
    await When('I proceed to checkout', null, { cartPage }); 
    await And('I check out as a guest with valid personal details and address', null, { checkoutPage }); 
    await And('I choose the shipping method "Flat Shipping Rate"', null, { checkoutPage }); 
    await And('I choose the payment method "Cash On Delivery"', null, { checkoutPage }); 
    await Then('the order cannot be confirmed', null, { checkoutPage }); 
    await When('I agree to the terms and conditions', null, { checkoutPage }); 
    await Then('the order can be confirmed', null, { checkoutPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/checkout.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":8,"tags":["@checkout","@IB-20","@smoke","@e2e"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I have added \"iPhone\" to the shopping cart","stepMatchArguments":[{"group":{"start":13,"value":"\"iPhone\"","children":[{"start":14,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":8,"gherkinStepLine":10,"keywordType":"Action","textWithKeyword":"When I proceed to checkout","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"And I check out as a guest with valid personal details and address","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":12,"keywordType":"Action","textWithKeyword":"And I choose the shipping method \"Flat Shipping Rate\"","stepMatchArguments":[{"group":{"start":29,"value":"\"Flat Shipping Rate\"","children":[{"start":30,"value":"Flat Shipping Rate","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":11,"gherkinStepLine":13,"keywordType":"Action","textWithKeyword":"And I agree to the terms and conditions","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":14,"keywordType":"Action","textWithKeyword":"And I choose the payment method \"Cash On Delivery\"","stepMatchArguments":[{"group":{"start":28,"value":"\"Cash On Delivery\"","children":[{"start":29,"value":"Cash On Delivery","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"And I confirm the order","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"Then the page heading is \"Your order has been placed!\"","stepMatchArguments":[{"group":{"start":20,"value":"\"Your order has been placed!\"","children":[{"start":21,"value":"Your order has been placed!","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":17,"pickleLine":19,"tags":["@checkout","@IB-20","@auth"],"steps":[{"pwStepLine":18,"gherkinStepLine":20,"keywordType":"Context","textWithKeyword":"Given I am logged in","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":21,"keywordType":"Context","textWithKeyword":"And I have added \"MacBook\" to the shopping cart","stepMatchArguments":[{"group":{"start":13,"value":"\"MacBook\"","children":[{"start":14,"value":"MacBook","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I proceed to checkout","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the page heading is \"Checkout\"","stepMatchArguments":[{"group":{"start":20,"value":"\"Checkout\"","children":[{"start":21,"value":"Checkout","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And the guest checkout option is not offered","stepMatchArguments":[]}]},
  {"pwTestLine":25,"pickleLine":26,"tags":["@checkout","@IB-20"],"steps":[{"pwStepLine":26,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"When I open the checkout page","stepMatchArguments":[]},{"pwStepLine":27,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then the page heading is \"Shopping Cart\"","stepMatchArguments":[{"group":{"start":20,"value":"\"Shopping Cart\"","children":[{"start":21,"value":"Shopping Cart","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":28,"gherkinStepLine":29,"keywordType":"Outcome","textWithKeyword":"And I see the message \"Your shopping cart is empty!\"","stepMatchArguments":[{"group":{"start":18,"value":"\"Your shopping cart is empty!\"","children":[{"start":19,"value":"Your shopping cart is empty!","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":31,"pickleLine":31,"tags":["@checkout","@IB-20"],"steps":[{"pwStepLine":32,"gherkinStepLine":32,"keywordType":"Context","textWithKeyword":"Given I have added \"iPhone\" to the shopping cart","stepMatchArguments":[{"group":{"start":13,"value":"\"iPhone\"","children":[{"start":14,"value":"iPhone","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":33,"gherkinStepLine":33,"keywordType":"Action","textWithKeyword":"When I proceed to checkout","stepMatchArguments":[]},{"pwStepLine":34,"gherkinStepLine":34,"keywordType":"Action","textWithKeyword":"And I check out as a guest with valid personal details and address","stepMatchArguments":[]},{"pwStepLine":35,"gherkinStepLine":35,"keywordType":"Action","textWithKeyword":"And I choose the shipping method \"Flat Shipping Rate\"","stepMatchArguments":[{"group":{"start":29,"value":"\"Flat Shipping Rate\"","children":[{"start":30,"value":"Flat Shipping Rate","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":36,"gherkinStepLine":36,"keywordType":"Action","textWithKeyword":"And I choose the payment method \"Cash On Delivery\"","stepMatchArguments":[{"group":{"start":28,"value":"\"Cash On Delivery\"","children":[{"start":29,"value":"Cash On Delivery","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":37,"gherkinStepLine":37,"keywordType":"Outcome","textWithKeyword":"Then the order cannot be confirmed","stepMatchArguments":[]},{"pwStepLine":38,"gherkinStepLine":38,"keywordType":"Action","textWithKeyword":"When I agree to the terms and conditions","stepMatchArguments":[]},{"pwStepLine":39,"gherkinStepLine":39,"keywordType":"Outcome","textWithKeyword":"Then the order can be confirmed","stepMatchArguments":[]}]},
]; // bdd-data-end